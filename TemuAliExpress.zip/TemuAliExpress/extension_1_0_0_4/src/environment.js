
var environment = {
  aliseeks: {
      url: 'https://www.aliseeks.com',
      api: 'https://api.aliseeks.com',
      referral: 'c-sbi'
  }
};
