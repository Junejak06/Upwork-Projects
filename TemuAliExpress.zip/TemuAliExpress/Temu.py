import pandas as pd
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import undetected_chromedriver as uc
import ssl
from selenium.common.exceptions import NoSuchElementException
import re

# For SSL issue
ssl._create_default_https_context = ssl._create_unverified_context

options = uc.ChromeOptions()
options.binary_location = r"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
driver = uc.Chrome(driver_executable_path=r"/usr/local/bin/chromedriver", options=options)

wait = WebDriverWait(driver, 10)  # Setting up a default wait time of 10 seconds

driver.get("https://www.temu.com/channel/best-sellers.html?filter_items=1%3A1&scene=home_title_bar_recommend&refer_page_el_sn=201341&_x_sessn_id=jhcuhnhlbr&refer_page_name=5-Star%20Rated&refer_page_id=10443_1696611819011_q95oaps8cl&refer_page_sn=10443")

# Click on the specified element
driver.find_element(By.XPATH, "//li[@id='splide01-slide02']//div[@class='_3FT75RMj']").click()

# Wait for the page to load
time.sleep(10)

products = []

# Track URLs to prevent duplicates
processed_urls = set()

while len(products) < 5000:
    product_elems = driver.find_elements(By.XPATH, "//div[@aria-label]")

    for product in product_elems:
        # Get rating
        rating_elems = product.find_elements(By.XPATH, ".//div[contains(@aria-label, 'score')]")
        rating = float(rating_elems[0].get_attribute('aria-label').split(' ')[0]) if rating_elems else 0

        # Get number of reviews
        review_elems = product.find_elements(By.XPATH, ".//span[@class='_2W4Cqryh']")
        reviews = int(re.sub(r'[^\d]', '', review_elems[0].text)) if review_elems else 0

        # Filter out products that don't meet the criteria
        if rating < 4.5 or reviews <= 5000:
            continue

        # Get product name, price, units sold
        name = product.find_element(By.XPATH, ".//h3[@class='_2XmIMTf3']").text
        price = product.find_element(By.XPATH, ".//div[@class='_2Ci4uR69']").text
        units_sold_elems = product.find_elements(By.XPATH, ".//span[@class='EPO3q5u9']")
        units_sold = units_sold_elems[0].text if units_sold_elems else '0'

        # Get product URL
        try:
            product_url_elem = product.find_element(By.TAG_NAME, "a")
            product_url = product_url_elem.get_attribute('href')
        except NoSuchElementException:
            product_url = ''

        # If we've processed this URL before, skip it
        if product_url in processed_urls:
            continue

        processed_urls.add(product_url)

        # Get product image
        try:
            image_elem = product.find_element(By.XPATH, ".//img")
            # If 'src' attribute is empty or null, try to get 'data-src' attribute.
            image_url = image_elem.get_attribute('src') or image_elem.get_attribute('data-src')
        except NoSuchElementException:
            image_url = ''

        # Get product category using JavaScript and try-except block
        try:
            category_script = "return arguments[0].innerText.trim().replace('in ', '');"
            category = driver.execute_script(category_script, product.find_element(By.XPATH, ".//div[@class='_2OyM96Bd']"))
        except NoSuchElementException:
            category = ''

        products.append([name, price, rating, reviews, units_sold, category, product_url, image_url])

        # Print the details of the product
        print(f"Product Name: {name}")
        print(f"Product Price: {price}")
        print(f"Product Rating: {rating}")
        print(f"Number of Reviews: {reviews}")
        print(f"Product Units Sold: {units_sold}")
        print(f"Product Category: {category}")
        print(f"Product URL: {product_url}")
        print(f"Product Image URL: {image_url}")
        print("-" * 50)  # Separator for better readability

        if len(products) >= 5000:
            break

    if len(products) >= 5000:
        break

    MAX_RETRIES = 3  # Maximum number of times we'll click "Try Again" before moving on

# ... [rest of your code]

    try:
        retries = 0
        see_more_btn = driver.find_element(By.XPATH, "//div[@class='_2U9ov4XG']")
        see_more_btn.click()

        while retries < MAX_RETRIES:
            try:
                # Try waiting for the new products to load
                wait.until(EC.presence_of_element_located((By.XPATH, "//div[@aria-label]")))
                break  # Break out of the loop if new products loaded
            except TimeoutException:
                try:
                    # If new products didn't load, try clicking the "Try Again" button (assuming it has the same locator as "See More")
                    try_again_btn = driver.find_element(By.XPATH, "//div[@class='_2U9ov4XG']")
                    try_again_btn.click()
                    retries += 1
                    time.sleep(2)  # Sleep for a bit before checking again
                except NoSuchElementException:
                    print("Neither new products nor 'Try Again' button found. Exiting the loop.")
                    break
    except NoSuchElementException:
        print("'See More' button not found. Trying to continue...")

    time.sleep(2)  # Give a break between iterations

# Convert products to a Pandas DataFrame and save to CSV
df = pd.DataFrame(products, columns=['Product Name', 'Product Price', 'Product Rating', 'Number of Reviews', 'Product Units Sold', 'Product Category', 'Product URL', 'Product Image URL'])
df.to_csv("temu_filtered_products.csv", index=False)

# Close the browser
driver.quit()
