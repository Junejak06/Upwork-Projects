import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import undetected_chromedriver as uc
import ssl
import os
from bs4 import BeautifulSoup
import time

# For SSL issue
ssl._create_default_https_context = ssl._create_unverified_context

options = uc.ChromeOptions()
options.binary_location = r"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
driver = uc.Chrome(driver_executable_path=r"/usr/local/bin/chromedriver", options=options)


def get_yahoo_data(symbol, driver):
    url = f"https://finance.yahoo.com/quote/{symbol}/key-statistics?p={symbol}"
    driver.get(url)

    time.sleep(5)

    soup = BeautifulSoup(driver.page_source, 'html.parser')
    print()

    try:
        trailing_pe_tag = soup.find("span", string="Trailing P/E")
        trailing_pe = trailing_pe_tag.find_next("td", class_="Fw(500)").text

        diluted_eps_tag = soup.find("span", string="Diluted EPS (ttm)")
        diluted_eps = diluted_eps_tag.find_next("td", class_="Fw(500)").text
    except AttributeError:
        print(f"Failed to get data for {symbol}.")
        return None, None

    return trailing_pe, diluted_eps


def main():
    # Load the CSV
    df = pd.read_csv("sp500_forecasts.csv")
    df_copy = df.copy()

    for index, row in df_copy.iterrows():
        symbol = row["Symbol"]
        trailing_pe, diluted_eps = get_yahoo_data(symbol, driver)
        r = pd.to_numeric(row["Median Estimate"], errors='coerce') / 100


        if trailing_pe and diluted_eps:
            intrinsic_value = diluted_eps * (1 + r) * trailing_pe
            df_copy.at[index, 'Trailing P/E'] = trailing_pe
            df_copy.at[index, 'Diluted EPS'] = diluted_eps
            df_copy.at[index, 'Intrinsic Value'] = intrinsic_value

            print(
                f"Symbol: {symbol}, Trailing P/E: {trailing_pe}, Diluted EPS: {diluted_eps}, Intrinsic Value: {intrinsic_value}")
        else:
            print(f"Failed to get data for {symbol}.")

    # Save the updated DataFrame to CSV
    df_copy.to_csv("Intrinsic_value.csv", index=False)


# If you're running this as a script:
if __name__ == "__main__":
    main()
