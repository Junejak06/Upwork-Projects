import yfinance as yf
import pandas as pd
import ssl
import re
import os
import openpyxl

# For SSL issue
ssl._create_default_https_context = ssl._create_unverified_context

def get_sp500_symbols():
    # Get the S&P 500 ticker list
    table = pd.read_html('https://en.wikipedia.org/wiki/List_of_S%26P_500_companies')
    df = table[0]
    return df['Symbol'].tolist()

symbols = get_sp500_symbols()

# Save to CSV
df_symbols = pd.DataFrame(symbols, columns=['Symbol'])
df_symbols.to_csv("sp500_stocks.csv", index=False)

print(f"Saved S&P 500 symbols to sp500_stocks.csv")