import yfinance as yf

def fetch_stock_info(ticker_symbol):
    stock = yf.Ticker(ticker_symbol)
    try:
        return stock.info
    except Exception as e:
        print(f"Error fetching data for {ticker_symbol}: {e}")
        return None

ticker = "MSFT"
info = fetch_stock_info(ticker)
if info:
    print(info)
else:
    print(f"Failed to retrieve data for {ticker}")