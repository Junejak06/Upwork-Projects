import requests

# Endpoint to get all spaces within a team
endpoint = "https://api.clickup.com/api/v2/team/3715939/space"

headers = {
    'Authorization': 'pk_3817504_JNFOUUS8XP18FU2R9K1D2T8JE5V94CY8'
}

response = requests.get(endpoint, headers=headers)
spaces_data = response.json()
print(spaces_data)

# Print all spaces and their IDs
#for space_data in spaces_data:
    #print(space_data['id'], space_data['name'])
