from captcha_solver import CaptchaSolver

solver = CaptchaSolver('browser')
raw_data = open('downloaded_captcha.png', 'rb').read()
print(solver.solve_captcha(raw_data))