from PIL import Image
import pytesseract
import cv2
import numpy as np
import re

def ocr_from_image(img_path):
    # Load with OpenCV
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    
    # Contrast Enhancement
    img = cv2.equalizeHist(img)
    
    # Binarization using Otsu's thresholding
    _, binary_img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    
    # Bilateral filtering
    processed_img = cv2.bilateralFilter(binary_img, 9, 75, 75)
    
    # Morphological operations
    kernel = np.ones((3,3),np.uint8)
    processed_img = cv2.dilate(processed_img, kernel, iterations=1)
    processed_img = cv2.erode(processed_img, kernel, iterations=1)
    
    # Convert back to PIL for Tesseract
    image = Image.fromarray(processed_img)
    
    # OCR with Tesseract
    config = '--psm 8 --oem 1 -c tessedit_char_whitelist=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    text = pytesseract.image_to_string(image, config=config)
    
    # Keep only alphanumeric characters
    clean_text = re.sub(r'[^a-zA-Z0-9]', '', text)
    
    return clean_text.strip()

if __name__ == "__main__":
    img_path = 'downloaded_captcha.png'
    recognized_text = ocr_from_image(img_path)
    print(recognized_text)